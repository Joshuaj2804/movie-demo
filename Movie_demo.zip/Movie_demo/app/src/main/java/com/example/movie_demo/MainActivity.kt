package com.example.movie_demo

import android.os.Bundle
import android.os.StrictMode
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.movie_demo.databinding.ActivityMainBinding
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONArray
import org.json.JSONObject


class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)
        StrictMode.setThreadPolicy( StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build())
        val thread = Thread {
            try {
                val aLogger = HttpLoggingInterceptor()
                aLogger.level = (HttpLoggingInterceptor.Level.BODY)
                val client: OkHttpClient =
                    OkHttpClient().newBuilder().addInterceptor(aLogger).build()
                val mediaType: MediaType? = "text/plain".toMediaTypeOrNull()
                val body: RequestBody = RequestBody.create(mediaType, "")
                val request: Request = Request.Builder()
                    .url("https://moviesdatabase.p.rapidapi.com/titles")
                    .method("GET", null)
                    .addHeader(
                        "X-RapidAPI-Key",
                        "16295c5e63msh60f240562b18cddp1ee0dbjsndcbf63e4c4f2"
                    )
                    .addHeader("X-RapidAPI-Host", "moviesdatabase.p.rapidapi.com")
                    .build()

                val response: Response = client.newCall(request).execute()
                val res2 = response.body?.string()
                val ki: JSONObject? = res2?.let { JSONObject(it) }
                val ki2 = JSONArray(ki?.getString("results"))
                Log.d("array", ki2.toString())
                //Your code goes here
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own actionz", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
}